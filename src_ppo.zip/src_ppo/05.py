import os
import gymnasium as gym
import numpy as np
from stable_baselines3 import PPO
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.vec_env import VecNormalize
from stable_baselines3.common.callbacks import EvalCallback

def main():
    # --- 1. 基础配置 ---
    ENV_ID = "BipedalWalker-v3"
    # 回退到表现最好的 master 版本
    LOAD_MODEL_PATH = "ppo_bipedalwalker_master" 
    LOAD_STATS_PATH = "vec_normalize_master.pkl"
    
    # 结果保存位置
    BEST_MODEL_DIR = "./final_stable_model/"
    os.makedirs(BEST_MODEL_DIR, exist_ok=True)
    
    # 训练 100万步。
    # 不要嫌长，因为我们要用极其严苛的标准筛选模型，需要给它足够的时间去尝试。
    TOTAL_TIMESTEPS = 1000000 
    N_ENVS = max(1, os.cpu_count() - 1)

    print(f"正在加载 Master 模型，准备进行严厉监考训练...")

    # --- 2. 训练环境 (解冻!) ---
    env = make_vec_env(ENV_ID, n_envs=N_ENVS)
    env = VecNormalize.load(LOAD_STATS_PATH, env)
    
    # 【关键修改】必须设为 True！
    # 刚才的实验证明，冻结参数会导致模型变脆。我们要让它继续动态适应。
    env.training = True 
    env.norm_reward = True

    # --- 3. 评估环境 (严厉的裁判) ---
    eval_env = make_vec_env(ENV_ID, n_envs=1)
    eval_env = VecNormalize.load(LOAD_STATS_PATH, eval_env)
    eval_env.training = False 
    eval_env.norm_reward = False

    # --- 4. 设置“严厉”回调函数 ---
    eval_callback = EvalCallback(
        eval_env,
        best_model_save_path=BEST_MODEL_DIR,
        log_path=BEST_MODEL_DIR,
        eval_freq=20000,       # 每 2万步考一次
        n_eval_episodes=20,    # 【核心】每次必须连考 20 局！
        deterministic=True,
        verbose=1
    )

    # --- 5. 加载模型并微调参数 ---
    model = PPO.load(
        LOAD_MODEL_PATH, 
        env, 
        device='cpu',
        custom_objects={
            "learning_rate": 0.0001, #稍微回调一点学习率，给它调整的空间
            "clip_range": 0.1        # 保持保守
        }
    )
    
    print("开始训练... 请耐心等待 'New best mean reward' 的出现。")
    print("只有当 20 局平均分创新高时，才会保存模型。")
    
    model.learn(total_timesteps=TOTAL_TIMESTEPS, callback=eval_callback)
    
    print("训练结束。去查看 final_stable_model 文件夹吧。")

    # --- 6. 最终验证 ---
    print("-" * 50)
    print("加载筛选出的【最强稳定版】进行验证...")
    
    best_model_path = os.path.join(BEST_MODEL_DIR, "best_model.zip")
    
    # 验证环境
    final_env = gym.make(ENV_ID, render_mode="rgb_array")
    from stable_baselines3.common.vec_env import DummyVecEnv
    final_env = DummyVecEnv([lambda: final_env])
    final_env = VecNormalize.load(LOAD_STATS_PATH, final_env) # 注意这里还是用旧的stats，因为eval不更新
    final_env.training = False
    final_env.norm_reward = False

    best_model = PPO.load(best_model_path, device='cpu')

    scores = []
    for i in range(1, 11):
        obs = final_env.reset()
        done = False
        total_reward = 0
        while True:
            action, _ = best_model.predict(obs, deterministic=True)
            obs, rewards, dones, infos = final_env.step(action)
            total_reward += rewards[0]
            if dones[0]:
                break
        
        scores.append(total_reward)
        result_str = "✅" if total_reward > 300 else "❌"
        print(f"最终测试 {i}/10: {total_reward:.2f} [{result_str}]")

    print(f"平均分: {np.mean(scores):.2f}")

if __name__ == "__main__":
    main()