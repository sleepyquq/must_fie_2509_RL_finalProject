import os
import gymnasium as gym
from stable_baselines3 import PPO
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.vec_env import VecNormalize
from stable_baselines3.common.callbacks import CheckpointCallback

def main():
    # --- 配置 ---
    ENV_ID = "BipedalWalker-v3"
    OLD_MODEL_PATH = "ppo_bipedalwalker_expert" # 你刚才保存的模型
    OLD_STATS_PATH = "vec_normalize.pkl"        # 你刚才保存的归一化参数
    
    NEW_MODEL_PATH = "ppo_bipedalwalker_master" # 新的模型名字
    NEW_STATS_PATH = "vec_normalize_master.pkl"
    
    # 再追加训练 100万步 (在 8核 CPU 上大概 5 分钟)
    TOTAL_TIMESTEPS = 1000000 
    N_ENVS = max(1, os.cpu_count() - 1)

    print(f"正在加载预训练模型，准备进行微调...")
    
    # 1. 创建环境 (必须和之前一模一样)
    env = make_vec_env(ENV_ID, n_envs=N_ENVS)
    
    # 2. 加载之前的归一化参数 (关键！)
    # 这样模型才不会觉得“世界突然变了”
    env = VecNormalize.load(OLD_STATS_PATH, env)
    # 确保开启训练模式，继续更新均值方差
    env.training = True 
    env.norm_reward = True

    # 3. 加载模型，并动态修改学习率
    # custom_objects 允许我们在加载时覆盖原来的参数
    # 我们把学习率从 0.0003 改为 0.00005 (降低 6 倍)
    model = PPO.load(
        OLD_MODEL_PATH, 
        env, 
        device='cpu',
        custom_objects={
            "learning_rate": 0.00005, 
            "clip_range": 0.1  # 减小剪切范围，让更新更保守
        }
    )
    
    print(f"开始微调训练 (学习率已降低, 目标: +{TOTAL_TIMESTEPS} 步)...")
    
    # 4. 继续训练
    model.learn(total_timesteps=TOTAL_TIMESTEPS)
    
    print("微调完成！")
    
    # 5. 保存最终版本
    model.save(NEW_MODEL_PATH)
    env.save(NEW_STATS_PATH)
    print(f"最终模型已保存: {NEW_MODEL_PATH}.zip")

    # --- 最终验证 ---
    print("-" * 50)
    print("开始最终 5 次测试...")
    
    eval_env = gym.make(ENV_ID, render_mode="rgb_array")
    from stable_baselines3.common.vec_env import DummyVecEnv
    eval_env = DummyVecEnv([lambda: eval_env])
    
    # 加载新的归一化参数
    eval_env = VecNormalize.load(NEW_STATS_PATH, eval_env)
    eval_env.training = False 
    eval_env.norm_reward = False

    final_model = PPO.load(NEW_MODEL_PATH, device='cpu')

    for i in range(1, 6):
        obs = eval_env.reset()
        done = False
        total_reward = 0
        while True:
            action, _ = final_model.predict(obs, deterministic=True)
            obs, rewards, dones, infos = eval_env.step(action)
            total_reward += rewards[0]
            if dones[0]:
                break
        
        result_str = "完美" if total_reward > 300 else ("通过" if total_reward > 250 else "失败")
        print(f"测试第 {i} 局得分: {total_reward:.2f} [{result_str}]")

if __name__ == "__main__":
    main()