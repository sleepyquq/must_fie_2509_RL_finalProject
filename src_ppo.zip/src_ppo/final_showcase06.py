import os
import gymnasium as gym
import numpy as np
import imageio
from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import VecNormalize
from stable_baselines3.common.vec_env import DummyVecEnv

def main():
    # --- 配置 ---
    ENV_ID = "BipedalWalker-v3"
    # 这里加载你刚才那个表现最好的模型文件夹
    # 注意：确保这里指向的是包含 best_model.zip 的文件夹路径，或者直接指向 .zip 文件
    # 根据你上一步的输出，最佳模型应该在 ./final_stable_model/best_model.zip
    MODEL_PATH = "./final_stable_model/best_model.zip"
    STATS_PATH = "vec_normalize_master.pkl" # 依然用这个最基础的统计数据
    
    OUTPUT_DIR = "./final_project_submission"
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    print(f"正在加载最终模型: {MODEL_PATH}")

    # --- 1. 准备环境 ---
    # 我们需要手动捕获图像，所以这里用原生 gym 环境 + DummyVecEnv
    env = gym.make(ENV_ID, render_mode="rgb_array")
    env = DummyVecEnv([lambda: env])
    
    # 加载归一化参数
    # 注意：一定要把 training 设为 False，不要再更新了
    env = VecNormalize.load(STATS_PATH, env)
    env.training = False 
    env.norm_reward = False

    # --- 2. 加载模型 ---
    model = PPO.load(MODEL_PATH, device='cpu')

    print("-" * 50)
    print("开始 100 局终极压力测试...")
    print("系统将自动录制其中得分最高的 3 局视频。")
    print("-" * 50)

    success_count = 0
    scores = []
    
    # 用于保存最高分视频的缓存
    top_3_records = [] # 格式: (score, video_frames)

    for episode in range(1, 101):
        obs = env.reset()
        done = False
        total_reward = 0
        frames = [] # 临时存储当前局的画面
        
        while True:
            # 记录画面
            frame = env.render()
            frames.append(frame)
            
            action, _ = model.predict(obs, deterministic=True)
            obs, rewards, dones, infos = env.step(action)
            total_reward += rewards[0]
            
            if dones[0]:
                break
        
        scores.append(total_reward)
        
        # 统计成功率
        is_success = total_reward > 300
        if is_success:
            success_count += 1
            status = "👑 完美"
        elif total_reward > 250:
            status = "✅ 通过"
        else:
            status = "❌ 失败"
            
        print(f"第 {episode}/100 局: {total_reward:.2f} [{status}]")

        # --- 视频筛选逻辑 ---
        # 如果是完美局，或者是目前最好的前3名之一，就处理视频
        if len(top_3_records) < 3:
            top_3_records.append((total_reward, frames))
            top_3_records.sort(key=lambda x: x[0], reverse=True) # 保持降序
        else:
            # 如果当前分数比第3名高，就替换掉第3名
            if total_reward > top_3_records[-1][0]:
                top_3_records.pop() # 删掉最差的
                top_3_records.append((total_reward, frames))
                top_3_records.sort(key=lambda x: x[0], reverse=True)

    # --- 3. 输出总结报告 ---
    avg_score = np.mean(scores)
    success_rate = (success_count / 100) * 100
    
    print("\n" + "=" * 50)
    print("🏆 最终验收报告 🏆")
    print("=" * 50)
    print(f"测试总局数: 100")
    print(f"完美通关数 (>300): {success_count}")
    print(f"真实成功率: {success_rate:.1f}%")
    print(f"平均得分: {avg_score:.2f}")
    
    if success_rate >= 90:
        print("评价: S级 (卓越)")
    elif success_rate >= 80:
        print("评价: A级 (优秀)")
    else:
        print("评价: B级 (良好)")
        
    # --- 4. 保存最好的视频 ---
    print("\n正在保存得分最高的 3 个视频...")
    for i, (score, frames) in enumerate(top_3_records):
        video_filename = os.path.join(OUTPUT_DIR, f"best_run_{i+1}_score_{score:.2f}.mp4")
        # 使用 imageio 保存视频，fps=50 是 Box2D 的标准帧率
        imageio.mimsave(video_filename, frames, fps=50)
        print(f"视频已保存: {video_filename}")

    env.close()

if __name__ == "__main__":
    main()