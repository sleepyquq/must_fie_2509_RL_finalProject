import os
import gymnasium as gym
import numpy as np
from stable_baselines3 import PPO
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.vec_env import VecNormalize
from gymnasium.wrappers import RecordVideo

def main():
    # --- 配置 ---
    ENV_ID = "BipedalWalker-v3"
    # 我们回退一步，使用之前的 master 版本，因为它底子最好
    LOAD_MODEL_PATH = "ppo_bipedalwalker_master" 
    LOAD_STATS_PATH = "vec_normalize_master.pkl"
    
    FINAL_MODEL_PATH = "ppo_bipedalwalker_polished"
    FINAL_STATS_PATH = "vec_normalize_polished.pkl"
    VIDEO_FOLDER = "./final_video_output"
    
    # 只需要跑很少的步数，让模型适应固定的归一化参数
    TOTAL_TIMESTEPS = 200000 
    N_ENVS = max(1, os.cpu_count() - 1)

    print(f"正在加载 Master 模型，准备进行最终固化训练...")

    # --- 1. 准备“冻结”的训练环境 ---
    env = make_vec_env(ENV_ID, n_envs=N_ENVS)
    
    # 加载之前的统计数据
    env = VecNormalize.load(LOAD_STATS_PATH, env)
    
    # 【核心操作】: 关闭 training 模式
    # 这意味着：观测值的均值(mean)和方差(var)将不再更新！
    # 模型必须适应这套固定的“世界观”。
    env.training = False 
    env.norm_reward = True # 奖励依然归一化，方便优化器工作

    # --- 2. 加载模型并调整参数 ---
    model = PPO.load(
        LOAD_MODEL_PATH, 
        env, 
        device='cpu',
        custom_objects={
            "learning_rate": 0.00001, #以此生最小的学习率进行微雕 (1e-5)
            "ent_coef": 0.0,          #以此禁止任何随机探索，追求绝对稳定
            "clip_range": 0.05        # 极小的更新幅度，防止破坏已有技能
        }
    )
    
    print(f"开始固化训练 (Stats Frozen, LR=1e-5)...")
    model.learn(total_timesteps=TOTAL_TIMESTEPS)
    print("固化完成！")
    
    # 保存最终版
    model.save(FINAL_MODEL_PATH)
    env.save(FINAL_STATS_PATH)
    print(f"最终模型已保存: {FINAL_MODEL_PATH}")

    # --- 3. 最终大考 (10次测试) ---
    print("-" * 50)
    print("开始最终 10 次压力测试...")
    
    eval_env = gym.make(ENV_ID, render_mode="rgb_array")
    
    # 包装录像功能 (只录制那些 > 300 分的完美视频，避免存下垃圾视频)
    eval_env = RecordVideo(
        eval_env, 
        video_folder=VIDEO_FOLDER, 
        name_prefix="perfect_run",
        episode_trigger=lambda x: True # 先暂时全部录制，后面我们可以筛选
    )
    
    from stable_baselines3.common.vec_env import DummyVecEnv
    eval_env = DummyVecEnv([lambda: eval_env])
    
    # 加载刚才固化的参数
    eval_env = VecNormalize.load(FINAL_STATS_PATH, eval_env)
    eval_env.training = False
    eval_env.norm_reward = False

    final_model = PPO.load(FINAL_MODEL_PATH, device='cpu')

    scores = []
    for i in range(1, 11):
        obs = eval_env.reset()
        done = False
        total_reward = 0
        while True:
            # 确定性模式
            action, _ = final_model.predict(obs, deterministic=True)
            obs, rewards, dones, infos = eval_env.step(action)
            total_reward += rewards[0]
            if dones[0]:
                break
        
        scores.append(total_reward)
        result_str = "👑 完美" if total_reward > 300 else ("✅ 通过" if total_reward > 250 else "❌ 失败")
        print(f"测试第 {i}/10 局: {total_reward:.2f} [{result_str}]")

    avg_score = np.mean(scores)
    print("-" * 50)
    print(f"10局平均分: {avg_score:.2f}")
    
    if avg_score > 300:
        print("🎉 恭喜！你已经达到了 Hardcore 级别的稳定性！")
    else:
        print("还可以，但仍有提升空间。")

    eval_env.close()

if __name__ == "__main__":
    main()