import os
import gymnasium as gym
from stable_baselines3 import PPO
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.vec_env import VecNormalize
from stable_baselines3.common.callbacks import EvalCallback # <--- 核心救星

def main():
    # --- 1. 配置 ---
    ENV_ID = "BipedalWalker-v3"
    # 加载你刚才微调过的模型（底子很好，不要浪费）
    LOAD_MODEL_PATH = "ppo_bipedalwalker_master" 
    LOAD_STATS_PATH = "vec_normalize_master.pkl"
    
    # 结果保存路径
    BEST_MODEL_DIR = "./best_model_log/"
    os.makedirs(BEST_MODEL_DIR, exist_ok=True)
    
    # 再跑 50万步足矣，因为我们要的是过程中的峰值
    TOTAL_TIMESTEPS = 500000 
    N_ENVS = max(1, os.cpu_count() - 1)

    print(f"正在加载模型，准备捕获最佳版本...")

    # --- 2. 准备训练环境 ---
    env = make_vec_env(ENV_ID, n_envs=N_ENVS)
    env = VecNormalize.load(LOAD_STATS_PATH, env)
    env.training = True 
    env.norm_reward = True

    # --- 3. 准备评估环境 (这是裁判) ---
    # EvalCallback 需要一个独立的评估环境来测试模型
    eval_env = make_vec_env(ENV_ID, n_envs=1) # 评估时用单线程即可
    eval_env = VecNormalize.load(LOAD_STATS_PATH, eval_env)
    eval_env.training = False # 评估时不更新归一化参数
    eval_env.norm_reward = False # 评估时看原始分数

    # --- 4. 设置“最佳模型”回调函数 (关键!) ---
    eval_callback = EvalCallback(
        eval_env,
        best_model_save_path=BEST_MODEL_DIR, # 最佳模型存哪里
        log_path=BEST_MODEL_DIR,
        eval_freq=10000,       # 每训练 1万步就考一次试
        n_eval_episodes=5,     # 每次考 5 局
        deterministic=True,    # 考试时用确定性策略
        render=False,
        verbose=1
    )

    # --- 5. 加载模型 ---
    model = PPO.load(LOAD_MODEL_PATH, env, device='cpu')

    print("开始最终训练。请留意控制台输出的 'New best mean reward'...")
    
    # --- 6. 训练 (带回调) ---
    model.learn(total_timesteps=TOTAL_TIMESTEPS, callback=eval_callback)
    
    print("训练结束。")
    print(f"请注意：我们不看最后的模型，我们要去 {BEST_MODEL_DIR} 找 best_model.zip")

    # --- 7. 验证那个“最佳模型” ---
    print("-" * 50)
    print("正在加载历史最佳模型 (best_model.zip) 进行最终验证...")
    
    # 这是一个新生成的最好的文件
    best_model_path = os.path.join(BEST_MODEL_DIR, "best_model.zip")
    
    final_env = gym.make(ENV_ID, render_mode="rgb_array")
    from stable_baselines3.common.vec_env import DummyVecEnv
    final_env = DummyVecEnv([lambda: final_env])
    
    # 依然需要加载归一化参数
    final_env = VecNormalize.load(LOAD_STATS_PATH, final_env)
    final_env.training = False
    final_env.norm_reward = False

    best_model = PPO.load(best_model_path, device='cpu')

    for i in range(1, 6):
        obs = final_env.reset()
        done = False
        total_reward = 0
        while True:
            action, _ = best_model.predict(obs, deterministic=True)
            obs, rewards, dones, infos = final_env.step(action)
            total_reward += rewards[0]
            if dones[0]:
                break
        
        result_str = "完美" if total_reward > 300 else "失败"
        print(f"最佳模型测试第 {i} 局得分: {total_reward:.2f} [{result_str}]")

if __name__ == "__main__":
    main()